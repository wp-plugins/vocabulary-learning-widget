This widget has been release under the GPL Open Source License. For more information visit: http://www.gnu.org/copyleft/gpl.html

This widget has been created by Early To Rise; a publishing company dedicated to improving the lives of people all around the world. Early To Rise believes that by improving your vocabulary, you greatly increase the chances of being a successful business person. 

Become a more persuasive writer and speaker ... build your self-confidence and intellect ... increase your attractiveness to others ... just by spending 10 VERY enjoyable minutes a day with ETR's new Words to the Wise.

This widget will display a random word from ETRs Word to the Wise dictionary of success words to your web site visitors.


INSTALLATION:

1. Upload the Daily-Word folder to your plug-in folder (wp-content\plugins) and activate it from the Plug-in section of your Word Press administration console.
2. Enable the 'widget' using your admin (Design >> Widgets)

You're done!
