<?php
/*
Plugin Name: Build Your Vocabulary
Plugin URI: http://www.earlytorise.com/
Description: Become a more persuasive writer and speaker ... build your self-confidence and intellect ... increase your attractiveness to others ... just by spending 10 VERY enjoyable minutes a day with ETR's new Words to the Wise 
Author: Edwin Huertas
Version: 1.0
Author URI: http://www.earlytorise.com/
*/

function success_words_content_gen($args) 
{
	extract($args);
	$title = __('Build Your Vocabulary ', 'Daily-Word');
	$today = date("Y-m-d");

	echo $before_widget ;
	echo $before_title . $title . $after_title;
	echo getTheWord($today);
	echo $after_widget;
}

function success_words_register() {
	if (!function_exists('register_sidebar_widget')) 
	{
			return;
	}

	register_sidebar_widget(__('Todays Success Word ', 'Daily-Word'),
		'success_words_content_gen');
}

function getTheWord($date)
	{
	$data = "<script type=\"text/javascript\" src=\"http://www.earlytorise.com/successWords.php?id=3&name=george\"></script><div align='right'><a href='http://www.earlytorise.com/issues/wise/word-definitions/' target='_blank'>Learning Vocabulary Words</a></div>";
	return $data;
	}

add_action('init', 'success_words_register');


?>
